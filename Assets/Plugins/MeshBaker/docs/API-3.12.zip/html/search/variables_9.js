var searchData=
[
  ['idealheight',['idealHeight',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#a1a4abff71c11fb8c612a535bd99b25e8',1,'DigitalOpus::MB::Core::MB3_TextureCombiner::MB_TexSet']]],
  ['idealwidth',['idealWidth',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_m_b___tex_set.html#ac72157f102d3c888a9c55b1f1ef60849',1,'DigitalOpus::MB::Core::MB3_TextureCombiner::MB_TexSet']]],
  ['indexesofbonesused',['indexesOfBonesUsed',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b___dynamic_game_object.html#a295afc0d0a9debd78f1cd246c11a8924',1,'DigitalOpus::MB::Core::MB3_MeshCombinerSingle::MB_DynamicGameObject']]],
  ['indexoftexsettorender',['indexOfTexSetToRender',['../class_m_b3___atlas_packer_render_texture.html#a6dca04ebe2e70e6143a626e1bdf900d7',1,'MB3_AtlasPackerRenderTexture']]],
  ['input',['input',['../class_m_b3___test_render_texture_test_harness.html#aa74ac4ae08d68fca4bff9a2f65ff96e7',1,'MB3_TestRenderTextureTestHarness']]],
  ['inputgameobject',['inputGameObject',['../class_m_b3___bone_weight_copier.html#a349b3697836005c2302588a903651bdc',1,'MB3_BoneWeightCopier']]],
  ['instanceid',['instanceID',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b___dynamic_game_object.html#a8afb97bf0c6575e61f41150027de7165',1,'DigitalOpus::MB::Core::MB3_MeshCombinerSingle::MB_DynamicGameObject']]],
  ['inverttriangles',['invertTriangles',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b___dynamic_game_object.html#a621e59982936f00cda2289afd4bc2481',1,'DigitalOpus::MB::Core::MB3_MeshCombinerSingle::MB_DynamicGameObject']]],
  ['isdirty',['isDirty',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html#a4240c4253864a55249d734478bc79e91',1,'DigitalOpus::MB::Core::MB3_MultiMeshCombiner::CombinedMesh']]],
  ['ismeshrenderer',['isMeshRenderer',['../class_digital_opus_1_1_m_b_1_1_core_1_1_game_object_filter_info.html#ac1f8bda721d46385388c2e163d4a0a27',1,'DigitalOpus::MB::Core::GameObjectFilterInfo']]],
  ['isnormalmap',['isNormalMap',['../class_m_b3___atlas_packer_render_texture.html#a7ab0b3ae217917de02607f83dfaa277c',1,'MB3_AtlasPackerRenderTexture.isNormalMap()'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_shader_texture_property.html#a644f41deb23e1feda44528ff90593138',1,'DigitalOpus.MB.Core.ShaderTextureProperty.isNormalMap()']]],
  ['isstatic',['isStatic',['../class_digital_opus_1_1_m_b_1_1_core_1_1_game_object_filter_info.html#a4f7a19f9293113bd24a65769f347820a',1,'DigitalOpus::MB::Core::GameObjectFilterInfo']]]
];
