var searchData=
[
  ['log',['Log',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___log.html#ab0af79b187f76c5f09e7d47ad7fd038b',1,'DigitalOpus.MB.Core.MB2_Log.Log()'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_object_log.html#a6c3a12665d5c8cdb9fe344f897963e6d',1,'DigitalOpus.MB.Core.ObjectLog.Log()']]],
  ['logdebug',['LogDebug',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___log.html#a721f517501e527119f166abb8594fb04',1,'DigitalOpus.MB.Core.MB2_Log.LogDebug()'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_object_log.html#a9dbf6a10404b36a196278b9cc3dc7fca',1,'DigitalOpus.MB.Core.ObjectLog.LogDebug()']]]
];
