var searchData=
[
  ['fixoutofboundsuvs',['fixOutOfBoundsUVs',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner.html#ae7596ff98e20520b2ff841b74103ff58',1,'DigitalOpus.MB.Core.MB3_TextureCombiner.fixOutOfBoundsUVs()'],['../class_m_b3___texture_baker.html#a912a430ff282fc1bdd0dd76d8a72e015',1,'MB3_TextureBaker.fixOutOfBoundsUVs()']]]
];
