var searchData=
[
  ['igroupbyfilter',['IGroupByFilter',['../interface_digital_opus_1_1_m_b_1_1_core_1_1_i_group_by_filter.html',1,'DigitalOpus::MB::Core']]]
];
