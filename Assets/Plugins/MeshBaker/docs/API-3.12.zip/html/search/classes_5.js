var searchData=
[
  ['objectlog',['ObjectLog',['../class_digital_opus_1_1_m_b_1_1_core_1_1_object_log.html',1,'DigitalOpus::MB::Core']]]
];
